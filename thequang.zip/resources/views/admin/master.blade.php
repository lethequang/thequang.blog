
@include('admin.header')
@include('admin.sidebar')
@yield('content')
@include('admin.footer')
